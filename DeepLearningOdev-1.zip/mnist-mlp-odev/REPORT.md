# MNIST Veri Seti ile MLP — Deney Raporu

## 1. Amaç
Bu çalışmada iki farklı MLP mimarisini MNIST üzerinde sıfırdan eğiterek gizli katman genişliğinin başarım ve eğitim süresine etkisini karşılaştırdım. Seçtiğim modeli kendi el yazımla oluşturduğum öğrenci numarası üzerinde de değerlendirdim. CNN veya önceden eğitilmiş model kullanmadım.

## 2. Veri seti ve ön işleme
MNIST, 0–9 arasındaki rakamları içeren 28×28 boyutlarında gri tonlamalı görüntülerden oluşuyor. Sağlanan 60.000 eğitim görüntüsünü sınıf dağılımını koruyarak **50,000 eğitim** ve **10,000 doğrulama** örneğine ayırdım. Ayrı olan **10,000 test** görüntüsünü nihai değerlendirme için ayırdım. Piksel değerlerini 255'e bölerek `[0,1]` aralığına getirdim. Rastgelelik tohumu **42** olarak belirlendi.

## 3. Model mimarisi ve hiperparametreler
Her iki modelde `Flatten(28×28) → Dense(ReLU) → Dense(ReLU) → Dense(10, Softmax)` yapısını kullandım. Temel modelin gizli katmanları **128–64**, geniş modelin gizli katmanları **256–128** nörondan oluşuyor. İki deneyde Adam optimizer, **0.001** öğrenme oranı, sparse categorical crossentropy loss, **128** batch size ve **10** epoch kullandım. Karşılaştırmada yalnızca gizli katman genişliğini değiştirdim.

## 4. Deney sonuçları
Aşağıdaki eğitim ve doğrulama değerleri son epoch'a aittir.

| Model | Gizli katmanlar | Parametre | Train loss | Val loss | Train accuracy | Val accuracy | Test loss | Test accuracy | Eğitim süresi |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| MLP-128-64 | (128, 64) | 109,386 | 0.0231 | 0.1028 | 99.40% | 97.31% | 0.1042 | 97.29% | 25.1 sn |
| MLP-256-128 | (256, 128) | 235,146 | 0.0138 | 0.1000 | 99.56% | 97.65% | 0.1021 | 97.62% | 40.7 sn |

Model seçimini son epoch doğrulama doğruluğuna göre yaptım; eşitlik halinde doğrulama kaybını kullandım. **MLP-256-128** modeli seçildi. İki modelin test metriklerini model seçimi tamamlandıktan sonra yalnızca nihai karşılaştırma için ölçtüm; test sonuçlarına bakarak model veya hiperparametre değiştirmedim.

![Eğitim ve doğrulama eğrileri](results/training_curves.png)

![Mimari karşılaştırması](results/model_comparison.png)

## 5. Sonuçların değerlendirilmesi
Geniş modelin son epoch doğrulama doğruluğu temel modelden **0.34 yüzde puan** yüksek. Eğitim süresi **15.6 saniye** (yaklaşık **%62**) daha uzun sürdü. Test doğruluğundaki fark **0.33 yüzde puan**. Daha fazla nöronla küçük bir doğruluk artışı elde ederken hesaplama maliyetinin de yükseldiğini gördüm.

Seçilen modelde doğrulama kaybı 6. epoch'ta 0.0879 iken son epoch'ta 0.1000 oldu. Son epoch eğitim ve doğrulama doğrulukları arasında 1.91 yüzde puanlık fark var. Bu durum hafif aşırı öğrenmeye işaret edebilir; tek başına kesin kanıt değildir. En yüksek doğrulama doğruluğu 8. epoch'ta **97.67%** olsa da seçim için başlangıçta belirlediğim son epoch ölçütünü korudum.

Seçilen modelin test sonuçlarına ait karışıklık matrisi ve sınıf bazında sınıflandırma raporu hangi rakamların daha fazla karıştırıldığını incelemek için kullanıldı.

![Test kümesi karışıklık matrisi](results/confusion_matrix.png)

## 6. Kendi el yazımla test
Kendi el yazımla oluşturduğum öğrenci numarası görüntüsündeki **11** rakamı ayrıştırdım. Gerçek numara `21120205047`, modelin tahmini `21120205047` oldu. **11/11** rakam doğru sınıflandırıldı (**100.00%**). Bu oran yalnızca incelediğim tek numara görüntüsüne aittir.

![El yazısı tahminleri](results/handwriting_predictions.png)

Rakam bazında güven skorları `results/handwriting_predictions.csv` dosyasında, kullanılan görüntüler `images/` klasöründe bulunuyor.

## 7. Genelleme ve sınırlamalar
MNIST'teki görüntüler standart boyutta ve ortalanmışken telefonla çektiğim fotoğrafta ışık, gölge, çizgi kalınlığı, eğim ve hizalama farklılıkları bulunabiliyor. Bu **veri dağılımı farkını (distribution shift)** azaltmak için görüntüyü gri tonlamaya çevirdim, Otsu eşikleme uyguladım, rakamları ayırıp MNIST düzeninde 28×28 boyutuna getirdim. Buna rağmen tek bir öğrenci numarası üzerinde ölçülen başarı, modelin her gerçek el yazısında aynı performansı göstereceği anlamına gelmiyor.

Rakam ayırma yöntemi tek satırda, birbirinden ayrık yazılmış rakamlara dayanıyor. Bitişik rakamlar ve güçlü gölgeler segmentasyonu zorlaştırabiliyor. Ayrıca bu çalışmada iki farklı katman genişliğini denedim; öğrenme oranı, regularization veya alternatif epoch sayıları için ayrı deneyler yapmadım.

## 8. Yeniden üretilebilirlik ve çıktı dosyaları
Bütün eğitim ve değerlendirme adımları `MNIST_MLP.ipynb` içinde bulunuyor. Epoch bazında veriler `results/epoch_history.csv`, model karşılaştırması `results/model_comparison.csv`, rakam tahminleri `results/handwriting_predictions.csv` ve toplu metrikler `results/metrics.json` altında kayıtlı. El yazısı fotoğrafı ile işlenmiş rakam görüntüleri `images/` klasöründe yer alıyor. Eğitim süresi ve son metrikler çalıştırma ortamına göre küçük farklılıklar gösterebilir.
