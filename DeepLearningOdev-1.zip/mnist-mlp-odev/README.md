# MNIST Veri Seti ile MLP Tabanlı El Yazısı Rakam Tanıma

## Proje hakkında

Bu projede MNIST veri setiyle iki farklı çok katmanlı algılayıcı (Multi-Layer Perceptron, MLP) eğittim. Temel amacım gizli katmanların genişliği değiştiğinde doğruluk, kayıp ve eğitim süresinin nasıl etkilendiğini görmekti. Ayrıca kendi el yazımla yazdığım öğrenci numarasının fotoğrafını işleyerek modelin MNIST dışındaki bir örnek üzerindeki tahminlerini inceledim.

Modelleri **sıfırdan** eğittim; **CNN veya hazır eğitilmiş bir model kullanmadım**. Tüm deneyler TensorFlow/Keras ile `MNIST_MLP.ipynb` dosyasında gerçekleştirildi.

## Veri seti ve yöntem

MNIST, 0'dan 9'a kadar el yazısı rakamlarını içeren 28×28 piksel gri tonlamalı görüntülerden oluşuyor. Veri ayrımını şöyle yaptım:

| Veri kümesi | Görüntü sayısı | Kullanım |
|---|---:|---|
| Eğitim (train) | 50.000 | Model ağırlıklarının öğrenilmesi |
| Doğrulama (validation) | 10.000 | Mimarilerin karşılaştırılması ve model seçimi |
| Test | 10.000 | Model seçimi sonrasındaki nihai değerlendirme |

Eğitim ve doğrulama kümelerini, MNIST'in 60.000 örnekten oluşan eğitim bölümünden **stratified split** ile ayırdım. Piksel değerlerini `[0,1]` aralığına normalleştirdim. Test kümesini model seçimi ve eğitim sırasında kullanmadım.

İki modelde de `Flatten → Dense(ReLU) → Dense(ReLU) → Dense(Softmax)` yapısı kullanıldı. Çıkış katmanında 10 nöron bulunuyor.

| Parametre | Deney 1 | Deney 2 |
|---|---|---|
| Gizli katmanlar | 128, 64 | 256, 128 |
| Aktivasyon | ReLU | ReLU |
| Optimizer | Adam | Adam |
| Learning rate | 0.001 | 0.001 |
| Loss | Sparse categorical crossentropy | Sparse categorical crossentropy |
| Batch size | 128 | 128 |
| Epoch | 10 | 10 |
| Random seed | 42 | 42 |

Bu düzenlemede değişen temel parametre gizli katmanlardaki nöron sayısıdır.

## Elde edilen sonuçlar

| Metrik | MLP-128-64 | MLP-256-128 |
|---|---:|---:|
| Training loss | 0.0231 | 0.0138 |
| Validation loss | 0.1028 | 0.1000 |
| Training accuracy | %99.40 | %99.56 |
| Validation accuracy | %97.31 | %97.65 |
| Test loss | 0.1042 | 0.1021 |
| Test accuracy | %97.29 | %97.62 |
| Eğitim süresi | 25.1 sn | 40.7 sn |

Doğrulama sonuçlarına göre **MLP-256-128** modelini seçtim. Bu model test kümesinde **%97.62** doğruluğa ulaştı. Daha geniş mimari temel modele göre **0.34 yüzde puan** daha yüksek doğrulama doğruluğu sağladı, ancak eğitim süresi yaklaşık **%62** arttı. Özellikle 6. epoch'tan sonra doğrulama kaybının artması hafif overfitting olabileceğini düşündürüyor.

![Training ve validation loss/accuracy grafikleri](results/training_curves.png)

![Modellerin son epoch doğruluğu ve eğitim süresi](results/model_comparison.png)

## Kendi el yazım üzerindeki tahminler

Öğrenci numaramı beyaz kâğıda siyah kalemle yazıp fotoğrafını çektim. Fotoğrafı gri tonlamaya dönüştürdüm; Otsu eşikleme, gürültü temizleme ve dikey boşluklara dayalı bölme işlemleriyle rakamları tek tek ayırdım. Her rakamı 28×28 piksel boyutuna getirip siyah zemin üzerinde ortaladım ve normalleştirdim.

Bu fotoğraftaki **11 rakamın 11'i de doğru tahmin edildi (%100)**. Bunun tek bir fotoğrafa ait bir sonuç olduğunu, bütün el yazılarında %100 doğruluk anlamına gelmediğini özellikle belirtmek gerekir.

![El yazısı tahminleri](results/handwriting_predictions.png)

![Fotoğraf üzerindeki rakam sınırları](results/segmentation.png)

Telefon kamerasıyla elde ettiğim görüntüde ışık, gölge ve yazı kalınlığı gibi özellikler MNIST görüntülerinden farklı. Bu nedenle kendi fotoğrafımın ön işlenmesi, modelin **distribution shift** karşısındaki davranışını gözlemlemek için önemliydi. Yöntemin özellikle bitişik rakamlar ve gölgeli görüntülerde sınırlamaları bulunuyor.

Deneyin daha ayrıntılı değerlendirmesi [REPORT.md](REPORT.md) dosyasında yer alıyor.

## Proje dosyaları

```text
mnist-mlp-odev/
├── MNIST_MLP.ipynb          # Veri hazırlama, eğitim, test ve el yazısı tahmini
├── README.md               # Proje özeti
├── REPORT.md               # Deney değerlendirmesi
├── requirements.txt        # Python bağımlılıkları
├── images/
│   ├── student_id_original.png
│   └── digits/             # 28x28'e dönüştürülen rakamlar
└── results/
    ├── training_curves.png
    ├── model_comparison.png
    ├── confusion_matrix.png
    ├── segmentation.png
    ├── handwriting_predictions.png
    ├── epoch_history.csv
    ├── model_comparison.csv
    ├── handwriting_predictions.csv
    ├── classification_report.txt
    ├── metrics.json
    └── selected_model.keras
```

## Çalıştırma

Proje Google Colab üzerinde çalıştırılacak şekilde hazırlandı. `MNIST_MLP.ipynb` dosyasındaki hücreler sırayla çalıştırıldığında MNIST indirilir, iki MLP eğitilir, grafikler ve test sonuçları oluşturulur. El yazısı tahmini bölümünde öğrenci numarası fotoğrafı yüklenir. Elde edilen görseller, tablolar ve deney raporu ilgili klasörlere kaydedilir.

Yerel bir Jupyter ortamında çalıştırmak için:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook MNIST_MLP.ipynb
```

Rastgelelik tohumu sabit olsa da donanım ve TensorFlow sürümü nedeniyle eğitim sürelerinde veya metriklerde küçük farklar görülebilir. `results/selected_model.keras` dosyası eğitimin sonunda kaydedilmiş model çıktısıdır; notebook eğitime hazır ağırlık yükleyerek başlamaz.
